#!/bin/bash
# Example cron job for running IdleGuard every night at 10 PM
# 
# 1. Install the package: pip install -e .
# 2. Create a config file: cp examples/config.yaml.example ~/.idle-guard/config.yaml
# 3. Set up AWS credentials (recommended: IAM role or ~/.aws/credentials)
# 4. Add to crontab: crontab -e
#
# Example entry (run at 22:00 every day):
# 0 22 * * * /path/to/idle-guard/scripts/cron_example.sh >> /var/log/idle-guard.log 2>&1

set -euo pipefail

# Path to your config (adjust as needed)
CONFIG_PATH="${HOME}/.idle-guard/config.yaml"

# Activate virtualenv if you use one (example)
# source /opt/venvs/idleguard/bin/activate

echo "=== IdleGuard nightly run started at $(date) ==="

# Run in dry-run mode first (recommended)
idle-guard scan --config "$CONFIG_PATH" --verbose

# To actually stop (uncomment after testing):
# idle-guard stop --config "$CONFIG_PATH" --no-dry-run --force

echo "=== IdleGuard run completed at $(date) ==="