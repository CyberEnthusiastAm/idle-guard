"""
IdleGuard - Automated Idle Cloud Resource Stopper
"""

__version__ = "0.1.0"
__author__ = "Open Source Contributors"