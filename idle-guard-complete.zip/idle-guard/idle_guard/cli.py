"""
IdleGuard CLI - Command line interface for detecting and stopping idle cloud resources.
"""

import json
import logging
import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import print as rprint

from .config import load_config
from .aws_scanner import AWSIdleScanner
from .notifier import Notifier

console = Console()

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("idle_guard")


@click.group()
@click.option("--config", "-c", type=click.Path(exists=False), default=None,
              help="Path to config YAML file (default: uses built-in defaults + env vars)")
@click.option("--verbose", "-v", is_flag=True, help="Enable debug logging")
@click.pass_context
def cli(ctx, config: Optional[str], verbose: bool):
    """IdleGuard - Automatically detect and stop idle cloud resources (e.g. dev VMs running overnight)."""
    ctx.ensure_object(dict)
    ctx.obj["config_path"] = config
    ctx.obj["verbose"] = verbose

    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)
        logger.debug("Verbose mode enabled")


@cli.command()
@click.option("--dry-run/--no-dry-run", default=None,
              help="Override dry-run setting from config")
@click.option("--region", "-r", multiple=True, help="Override regions (can be used multiple times)")
@click.pass_context
def scan(ctx, dry_run: Optional[bool], region: tuple):
    """Scan for idle resources without stopping them (or with override)."""
    config = load_config(ctx.obj.get("config_path"))
    if region:
        config["aws"]["regions"] = list(region)

    scanner = AWSIdleScanner(config)
    notifier = Notifier(config)

    with console.status("[bold green]Scanning for idle resources..."):
        results = scanner.process_idle_instances(dry_run=True)  # Always dry-run for scan command

    _display_results(results, console)

    if notifier.enabled:
        notifier.notify_scan_results(results)


@cli.command()
@click.option("--dry-run/--no-dry-run", default=None,
              help="Override dry-run from config. Use --no-dry-run to actually stop instances!")
@click.option("--region", "-r", multiple=True, help="Override regions")
@click.option("--force", is_flag=True, help="Skip confirmation prompt (use with caution)")
@click.pass_context
def stop(ctx, dry_run: Optional[bool], region: tuple, force: bool):
    """Find idle resources and stop them (respects dry-run by default)."""
    config = load_config(ctx.obj.get("config_path"))
    if region:
        config["aws"]["regions"] = list(region)

    # Determine final dry_run
    if dry_run is None:
        dry_run = config.get("actions", {}).get("dry_run", True)

    if not dry_run and not force:
        if not click.confirm(
            "⚠️  This will ACTUALLY STOP instances in production. Are you sure?",
            default=False
        ):
            console.print("[yellow]Aborted.[/yellow]")
            return

    scanner = AWSIdleScanner(config)
    notifier = Notifier(config)

    with console.status("[bold red]Processing idle resources..."):
        results = scanner.process_idle_instances(dry_run=dry_run)

    _display_results(results, console)

    if notifier.enabled:
        notifier.notify_scan_results(results)


def _display_results(results: dict, console: Console):
    """Pretty print results using Rich."""
    idle_count = results.get("idle_found", 0)
    dry_run = results.get("dry_run", True)

    if idle_count == 0:
        console.print(Panel.fit(
            "[bold green]✅ No idle resources found.[/bold green]\n"
            f"Regions scanned: {', '.join(results.get('scanned_regions', []))}",
            title="IdleGuard Scan Complete",
            border_style="green"
        ))
        return

    title = "🛑 Idle Resources Found" + (" (DRY RUN)" if dry_run else " (ACTION TAKEN)")
    color = "yellow" if dry_run else "red"

    table = Table(title=title, show_header=True, header_style="bold magenta")
    table.add_column("Instance ID", style="cyan")
    table.add_column("Region", style="blue")
    table.add_column("Type", style="green")
    table.add_column("Avg CPU %", justify="right", style="yellow")
    table.add_column("Tags (key ones)", style="white")

    stopped_list = results.get("stopped", [])
    if not stopped_list:
        # Fallback for older result structures
        stopped_list = results.get("idle_found_details", [])

    for inst in stopped_list:
        tags_str = ", ".join([f"{k}={v}" for k, v in list(inst.get("Tags", {}).items())[:3]])
        table.add_row(
            inst.get("InstanceId", "N/A"),
            inst.get("Region", "N/A"),
            inst.get("InstanceType", "N/A"),
            str(inst.get("AvgCPU", "N/A")),
            tags_str or "-"
        )

    console.print(table)

    summary = (
        f"[bold]Total idle found:[/bold] {idle_count}\n"
        f"[bold]Regions scanned:[/bold] {', '.join(results.get('scanned_regions', []))}\n"
        f"[bold]Mode:[/bold] {'DRY RUN' if dry_run else 'LIVE - Instances were stopped'}"
    )
    console.print(Panel(summary, title="Summary", border_style=color))

    if results.get("failed"):
        console.print("[bold red]Some stops failed. Check logs.[/bold red]")


@cli.command()
@click.pass_context
def config_show(ctx):
    """Show the effective configuration (useful for debugging)."""
    config = load_config(ctx.obj.get("config_path"))
    console.print(Panel.fit(
        json.dumps(config, indent=2, default=str),
        title="Effective IdleGuard Configuration",
        border_style="blue"
    ))


if __name__ == "__main__":
    cli()