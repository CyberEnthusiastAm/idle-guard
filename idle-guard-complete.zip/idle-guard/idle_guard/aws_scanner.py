"""
AWS resource scanner and idle detection logic for IdleGuard.
Currently focused on EC2 instances. Easily extensible to other resources.
"""

import datetime
import logging
from typing import Any, Dict, List, Optional, Tuple

import boto3
from botocore.exceptions import ClientError, NoCredentialsError

from .config import get_aws_session

logger = logging.getLogger(__name__)


class AWSIdleScanner:
    def __init__(self, config: Dict[str, Any], session: Optional[boto3.Session] = None):
        self.config = config
        self.session = session or get_aws_session(config.get("aws", {}).get("profile"))
        self.idle_config = config.get("idle_detection", {})
        self.aws_config = config.get("aws", {})

    def get_regions(self) -> List[str]:
        """Get list of regions to scan."""
        regions = self.aws_config.get("regions", ["us-east-1"])
        if isinstance(regions, str):
            regions = [r.strip() for r in regions.split(",")]
        return regions

    def should_consider_instance(self, instance: Dict[str, Any]) -> bool:
        """Check if instance matches our tagging rules for auto-stop consideration."""
        tags = {tag["Key"]: tag["Value"] for tag in instance.get("Tags", [])}

        exclude_tags = self.idle_config.get("exclude_tags", {})
        for key, values in exclude_tags.items():
            if key in tags and tags[key].lower() in [v.lower() for v in values]:
                logger.debug(f"Instance {instance['InstanceId']} excluded by tag {key}={tags[key]}")
                return False

        check_tags = self.idle_config.get("check_tags", {})
        if not check_tags:
            return True  # No filter = consider all (use with caution)

        for key, values in check_tags.items():
            if key in tags and tags[key].lower() in [v.lower() for v in values]:
                return True

        return False

    def get_cpu_utilization(self, instance_id: str, region: str, period_minutes: int) -> Optional[float]:
        """Fetch average CPU utilization from CloudWatch for the given period."""
        try:
            cloudwatch = self.session.client("cloudwatch", region_name=region)
            end_time = datetime.datetime.utcnow()
            start_time = end_time - datetime.timedelta(minutes=period_minutes)

            response = cloudwatch.get_metric_statistics(
                Namespace="AWS/EC2",
                MetricName="CPUUtilization",
                Dimensions=[{"Name": "InstanceId", "Value": instance_id}],
                StartTime=start_time,
                EndTime=end_time,
                Period=300,  # 5-minute periods
                Statistics=["Average"],
            )

            datapoints = response.get("Datapoints", [])
            if not datapoints:
                logger.warning(f"No CloudWatch data for {instance_id} in last {period_minutes} minutes")
                return None

            avg_cpu = sum(dp["Average"] for dp in datapoints) / len(datapoints)
            return round(avg_cpu, 2)
        except ClientError as e:
            logger.error(f"CloudWatch error for {instance_id}: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error fetching metrics for {instance_id}: {e}")
            return None

    def find_idle_instances(self, region: str) -> List[Dict[str, Any]]:
        """Find running instances that appear idle based on config."""
        ec2 = self.session.client("ec2", region_name=region)
        idle_instances = []

        try:
            response = ec2.describe_instances(
                Filters=[{"Name": "instance-state-name", "Values": ["running"]}]
            )

            period_min = self.idle_config.get("idle_period_minutes", 60)
            cpu_threshold = self.idle_config.get("cpu_threshold_percent", 5.0)
            min_uptime_min = self.idle_config.get("min_uptime_minutes", 30)

            now = datetime.datetime.utcnow()

            for reservation in response.get("Reservations", []):
                for instance in reservation.get("Instances", []):
                    instance_id = instance["InstanceId"]
                    launch_time = instance.get("LaunchTime")

                    # Skip recently launched instances
                    if launch_time:
                        uptime = (now - launch_time.replace(tzinfo=None)).total_seconds() / 60
                        if uptime < min_uptime_min:
                            logger.debug(f"Skipping {instance_id}: too recently launched ({uptime:.1f} min)")
                            continue

                    if not self.should_consider_instance(instance):
                        continue

                    avg_cpu = self.get_cpu_utilization(instance_id, region, period_min)

                    if avg_cpu is not None and avg_cpu < cpu_threshold:
                        idle_instances.append({
                            "InstanceId": instance_id,
                            "Region": region,
                            "InstanceType": instance.get("InstanceType"),
                            "LaunchTime": launch_time,
                            "AvgCPU": avg_cpu,
                            "Tags": {tag["Key"]: tag["Value"] for tag in instance.get("Tags", [])},
                            "State": instance.get("State", {}).get("Name"),
                        })
                        logger.info(f"IDLE DETECTED: {instance_id} in {region} - Avg CPU: {avg_cpu}%")

        except NoCredentialsError:
            logger.error("AWS credentials not found. Configure AWS CLI or set credentials.")
            raise
        except ClientError as e:
            logger.error(f"AWS API error in {region}: {e}")
        except Exception as e:
            logger.error(f"Unexpected error scanning {region}: {e}")

        return idle_instances

    def stop_instance(self, instance_id: str, region: str, dry_run: bool = True) -> bool:
        """Stop an EC2 instance. Returns True if successful (or dry-run)."""
        try:
            ec2 = self.session.client("ec2", region_name=region)
            if dry_run:
                logger.info(f"[DRY-RUN] Would stop instance {instance_id} in {region}")
                return True

            response = ec2.stop_instances(InstanceIds=[instance_id])
            logger.info(f"Successfully initiated stop for {instance_id} in {region}")
            return True
        except ClientError as e:
            logger.error(f"Failed to stop {instance_id}: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error stopping {instance_id}: {e}")
            return False

    def scan_all_regions(self) -> List[Dict[str, Any]]:
        """Scan all configured regions and return list of idle instances."""
        all_idle = []
        for region in self.get_regions():
            logger.info(f"Scanning region: {region}")
            idle_in_region = self.find_idle_instances(region)
            all_idle.extend(idle_in_region)
        return all_idle

    def process_idle_instances(self, dry_run: Optional[bool] = None) -> Dict[str, Any]:
        """Main entry point: find idle instances and optionally stop them."""
        if dry_run is None:
            dry_run = self.config.get("actions", {}).get("dry_run", True)

        idle_instances = self.scan_all_regions()

        stopped = []
        failed = []

        for inst in idle_instances:
            success = self.stop_instance(
                inst["InstanceId"],
                inst["Region"],
                dry_run=dry_run
            )
            if success:
                stopped.append(inst)
            else:
                failed.append(inst)

        return {
            "scanned_regions": self.get_regions(),
            "idle_found": len(idle_instances),
            "stopped": stopped,
            "failed": failed,
            "dry_run": dry_run,
        }