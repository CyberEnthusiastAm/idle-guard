"""
Configuration management for IdleGuard.
Supports YAML file, environment variables, and sensible defaults.
"""

import os
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
from dotenv import load_dotenv

# Load .env if present
load_dotenv()

DEFAULT_CONFIG = {
    "aws": {
        "regions": ["us-east-1"],
        "profile": None,  # Use default or named profile
    },
    "idle_detection": {
        "cpu_threshold_percent": 5.0,
        "idle_period_minutes": 60,
        "min_uptime_minutes": 30,  # Don't stop instances started very recently
        "check_tags": {  # Instances must have at least one of these to be considered
            "Environment": ["dev", "development", "test", "staging"],
            "AutoStop": ["true", "yes", "enabled"],
        },
        "exclude_tags": {  # Never stop if has these tags
            "DoNotStop": ["true", "yes"],
            "Environment": ["prod", "production"],
        },
    },
    "actions": {
        "dry_run": True,
        "stop_instances": True,
    },
    "notifications": {
        "enabled": False,
        "slack_webhook_url": None,
        "notify_on_stop": True,
        "notify_on_dry_run": False,
    },
    "logging": {
        "level": "INFO",
    },
}


def load_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    """Load configuration from file or return defaults + env overrides."""
    config = DEFAULT_CONFIG.copy()

    # Load from YAML if provided
    if config_path:
        path = Path(config_path)
        if path.exists():
            with open(path, "r") as f:
                file_config = yaml.safe_load(f) or {}
                # Deep merge
                config = deep_merge(config, file_config)
        else:
            print(f"Warning: Config file {config_path} not found. Using defaults.")

    # Override with environment variables (simple flat override for demo)
    env_overrides = {
        "aws.regions": os.getenv("IDLEGUARD_AWS_REGIONS"),
        "idle_detection.cpu_threshold_percent": os.getenv("IDLEGUARD_CPU_THRESHOLD"),
        "idle_detection.idle_period_minutes": os.getenv("IDLEGUARD_IDLE_MINUTES"),
        "actions.dry_run": os.getenv("IDLEGUARD_DRY_RUN"),
        "notifications.enabled": os.getenv("IDLEGUARD_NOTIFICATIONS_ENABLED"),
        "notifications.slack_webhook_url": os.getenv("IDLEGUARD_SLACK_WEBHOOK"),
    }

    for key, value in env_overrides.items():
        if value is not None:
            keys = key.split(".")
            d = config
            for k in keys[:-1]:
                d = d.setdefault(k, {})
            # Type conversion
            if key.endswith("percent") or key.endswith("minutes"):
                try:
                    d[keys[-1]] = float(value)
                except ValueError:
                    pass
            elif key.endswith("dry_run") or key.endswith("enabled"):
                d[keys[-1]] = value.lower() in ("true", "1", "yes")
            else:
                d[keys[-1]] = value

    return config


def deep_merge(base: Dict, override: Dict) -> Dict:
    """Recursively merge override into base."""
    for key, value in override.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            base[key] = deep_merge(base[key], value)
        else:
            base[key] = value
    return base


def get_aws_session(profile: Optional[str] = None):
    """Get boto3 session (supports profile)."""
    import boto3
    if profile:
        return boto3.Session(profile_name=profile)
    return boto3.Session()