"""
Notification module for IdleGuard.
Currently supports Slack webhooks. Easy to extend to email, SNS, Teams, etc.
"""

import json
import logging
from typing import Any, Dict, List

import requests

logger = logging.getLogger(__name__)


class Notifier:
    def __init__(self, config: Dict[str, Any]):
        self.config = config.get("notifications", {})
        self.enabled = self.config.get("enabled", False)
        self.slack_webhook = self.config.get("slack_webhook_url")
        self.notify_on_stop = self.config.get("notify_on_stop", True)
        self.notify_on_dry_run = self.config.get("notify_on_dry_run", False)

    def send_slack_message(self, message: str, blocks: List[Dict] = None) -> bool:
        """Send a message to Slack via webhook."""
        if not self.slack_webhook:
            logger.warning("Slack webhook URL not configured")
            return False

        payload = {"text": message}
        if blocks:
            payload["blocks"] = blocks

        try:
            response = requests.post(
                self.slack_webhook,
                data=json.dumps(payload),
                headers={"Content-Type": "application/json"},
                timeout=10,
            )
            if response.status_code == 200:
                logger.info("Slack notification sent successfully")
                return True
            else:
                logger.error(f"Slack notification failed: {response.status_code} - {response.text}")
                return False
        except Exception as e:
            logger.error(f"Error sending Slack notification: {e}")
            return False

    def notify_scan_results(self, results: Dict[str, Any]) -> None:
        """Send notification about scan results."""
        if not self.enabled:
            return

        dry_run = results.get("dry_run", True)
        idle_count = results.get("idle_found", 0)
        stopped = results.get("stopped", [])
        failed = results.get("failed", [])

        if idle_count == 0:
            return  # Nothing to report

        if dry_run and not self.notify_on_dry_run:
            return
        if not dry_run and not self.notify_on_stop:
            return

        title = "🛑 IdleGuard - Idle Resources Detected"
        if dry_run:
            title += " (DRY RUN)"

        message = f"{title}\n\n"
        message += f"**Idle instances found:** {idle_count}\n"
        message += f"**Regions scanned:** {', '.join(results.get('scanned_regions', []))}\n\n"

        if stopped:
            message += "**Stopped / Would Stop:**\n"
            for inst in stopped:
                message += f"• `{inst['InstanceId']}` ({inst['InstanceType']}) in {inst['Region']} — Avg CPU: {inst['AvgCPU']}%\n"

        if failed:
            message += "\n**Failed to stop:**\n"
            for inst in failed:
                message += f"• `{inst['InstanceId']}` in {inst['Region']}\n"

        # Simple text for now; could enhance with blocks
        self.send_slack_message(message)